/******************************************************************************
 ** Copyright 2025-2026 OPLUS Mobile Comm Corp., Ltd.
 ** All rights reserved.
 **
 ** File: sink_manager.h
 ** Description: SinkManager header
 ** Version: 1.0
 ** Date : 2025-03-29
 ** Author: Yongzheng.an
 ** -----------------------------Revision History: ----------------------------
 ** <author>                    <date>     <version > <desc>
 ********************************************************************************/
#ifndef OPLUS_ODMF_SINK_MANAGER_H_
#define OPLUS_ODMF_SINK_MANAGER_H_

#include <atomic>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#if defined(OPLUS_ENABLE_H265) && defined(WEBRTC_WIN)
namespace webrtc {
class H265DecoderListener;
}  // namespace webrtc
#endif  // OPLUS_ENABLE_H265 && WEBRTC_WIN
#if defined(WIN32)
#include <vector>
#endif  // WIN32

#include "sink_client_listener.h"

struct DxgiAdapterLuid {
    uint32_t low_part;
    int32_t high_part;
};

class HardwareCapabilityHelper;
class OdmfEngine;
class OdmfListener;
class RemoteControlExtendedModeAdapter;

namespace webrtc {
class Thread;
}

enum class CastMode { Common, Leisure, Game_Phone, Extended_Display };

enum class NetworkType {
    Usb,
    P2p_5G,
    Wifi_5G,
    P2p_24G,
    Wifi_24G,
    Cloud,
    Unknown
};

enum class ExtendedSubMode { Mirror, Extended, Unkown };
enum class ExtendedAudioMode { Local, Remote };

struct SinkClientInfo {
    // client id
    int id = -1;
    // transport bus id
    std::string transport_bus_id;
    // expected video width
    int width = -1;
    // expected video height
    int height = -1;
    // frame rate
    int frame_rate = 60;
    // bitrate in kbps for encode
    float bitrate = 0;
    bool rotates_with_content = true;
    bool fold_rotates_with_content = true;
    float scale = 1.0;
    // actual video width
    int actual_width = -1;
    // actual video height
    int actual_height = -1;
    // actual rotation
    int actual_rotation = -1;
    // recording status
    bool recording = false;
    // recording filename
    std::string record_filename;
    // actual fold
    int actual_fold = -1;
    // REMOTE_DISCONNECT already reported via OnErrorNotify; reset on StartClient
    // connect success (client remains in map).
    bool remote_disconnect_notified = false;
    // Set when StopClient is called; suppress further OnStateChanged (e.g. media
    // failed from Disconnect) until the client is erased from the map.
    bool stopping = false;
    // Deferred DISPLAY_RESOLUTION notify from SwitchExtendedSubMode; cleared when
    // SetExtendedDisplayResolution runs in the same operation_thread_ batch.
    // When resolution params are unchanged, SUB_MODE is sent with force=true instead.
    bool resolution_notify_pending = false;

    SinkClientInfo(int id, std::string bus_id)
        : id(id), transport_bus_id(bus_id)
    {
    }
    SinkClientInfo() { }
};

struct SinkBigDataInfo {
    float avg_render_fps = 0.0f;
    int64_t avg_end_to_end_delay_sum_ms = -1;
    int video_codec = 0;
    int video_width = 0;
    int video_height = 0;
};

struct SinkCpuAndMemoryInfo {
    float cpu_usage = 0.0f;
    float memory_usage = 0.0f;
};

#if defined(WIN32)
class __declspec(dllexport) SinkManager {
#else
class __attribute__((visibility("default"))) SinkManager {
#endif  // WIN32
   public:
    static SinkManager& getInstance();
    ~SinkManager();

    // Get global and unique auth info, return "" if failed
    const char* GetAuthInfo(bool create_new);
    // Create sink client
    int CreateSinkClient(
        CastMode cast_mode = CastMode::Common, bool single_audio = true);
    int SetPcCastNetworkType(int client_id, NetworkType type, const char* ip);
    // Client start connect server and media
    int StartClient(int client_id,
        const char* ip,
        int port,
        int width,
        int height,
        int frame_rate);
    // Client start connect server and media with bitrate in kbps
    int StartClient(int client_id,
        const char* ip,
        int port,
        int width,
        int height,
        int frame_rate,
        ExtendedSubMode sub_mode,
        float bitrate = 0.0);
    // Release sink client
    void StopClient(int client_id);
    // Update the related source params
    void SetParameters(int client_id, int width, int height, int frame_rate);
    // Set video renderer to sdk
    void AddRemoteVideoRenderer(int client_id, void* qt_parent_view);
    // Start recorder
    void StartRecorder(int client_id, const char* path);
    // Stop recorder
    void StopRecorder(int client_id);
    // Release all resources. Stops all clients first (queued disconnects on the
    // engine thread), then destroys OdmfEngine and waits for async teardown before
    // deleting the engine pointer — avoids audio/render vs. engine teardown races.
    void Destroy();
    // Send reverse control message
    void SendReverseControlMessage(int client_id, uint8_t* data, size_t len);
    // Set sink client observer
    void RegisterSinkClientListener(SinkClientListener* listener);
    // get sink big data info
    SinkBigDataInfo GetSinkBigDataInfo(int client_id);
    // Whether enabling hardware acceleration decoding or not
    void EnableHardwareAcceleration(bool enable, bool is_encoder = false);
    // Return whether the pc supports hardware acceleration
    bool IsHardwareAccelerationSupported();
    // Obtain the max cast frame rate
    int GetMaxCastFrameRate(
        bool enable_hardware_acceleration, const char* model_name);
    // get sink cpu and memory info
    SinkCpuAndMemoryInfo GetSinkCpuAndMemoryInfo();
    // Push video frame to client
    void PushVideoFrame(int client_id,
        void* texture_handle,
        int64_t frame_index,
        int width,
        int height,
        uint64_t timestamp);
    // setup black hole environment
    void InstallBlackHoleEnvironment();
    // Internal methods
    // Handle data from engine
    void ParseReceivedData(const std::string& bus_id, const std::string& data);
    // Handle connection changes
    void HandleConnectionChanges(const std::string& bus_id, int state);
    // Handle connection changes
    void HandleVideoResolutionChanged(
        const std::string& bus_id, int width, int height, int rotation);
    // Handle first frame prepared
    void HandleFirstFramePrepared(const std::string& bus_id);
    // Handle first video frame sent
    void HandleFirstVideoFrameSent(const std::string& bus_id);
    // Handle first key frame received
    void HandleFirstKeyFrameReceived(const std::string& bus_id,
        const uint8_t* argb_data,
        int width,
        int height);
    // Handle last key frame received
    void HandleLastKeyFrameReceived(const std::string& bus_id,
        const uint8_t* argb_data,
        int width,
        int height);
    // Handle OnError callback from odmf
    void HandleInternalError(const std::string& bus_id,
        const std::string& error_code,
        const std::string& error_msg);

    void HandleExtendedSubModeChanged(const std::string& bus_id, bool success);
    // switch audio mode for extended display
    void SwitchAudioMode(int client_id, ExtendedAudioMode mode);

    // Configure target display identification for remote control by
    // display friendly name. The name will be passed down to the remote
    // control pipeline (ultimately to the platform-specific
    // ScreenInfoProvider on macOS).
    void SetRemoteControlDisplayName(
        int client_id, const std::string& friendly_name, int product_id);
    // switch extended sub mode for extended display
    void SwitchExtendedSubMode(
        int client_id, ExtendedSubMode sub_mode, int width, int height);
    // set extended display resolution for extended display and notify pad
    void SetExtendedDisplayResolution(
        int client_id, int width, int height, int rotation);
    ExtendedSubMode GetExtendedSubMode(int client_id);
    void StopMirror(int client_id, bool is_stop_audio);
    void ReStartMirror(int client_id, int width, int height);
    void SetEnableDumpVideo();
#if defined(WIN32)
    // bind luid transmitted from interconnection, and create device on this
    // luid
    void SetPreferredAdapterLuid(int client_id, DxgiAdapterLuid luid);
#endif // WIN32
    // Handle OnClientDisconnected callback from odmf
    void HandleClientDisconnected(
        const char* peer_id, bool is_initiator, bool is_remote_audio);
    void HandleH265DecoderError(int client_id, int code, const char* reason);
    // Disable copy ctor and assignment operation
    SinkManager(const SinkManager&) = delete;
    SinkManager& operator=(const SinkManager&) = delete;

   private:
    SinkManager();
    void ReportSetParamsResult(int id, bool result);

    int GetClientIdFromMap(const std::string& bus_id);
    void SendExpectedMediaParams(int client_id, bool via_signaling = false);
    void AppendCurrentTimeToReverseMessage(
        std::vector<uint8_t>& data, bool big_endian = true);
    void NotifyDisplayResolution(const std::string& transport_bus_id,
        int width,
        int height,
        int rotation);
    // force=true: receiver should flush UI gate (e.g. onFirstFrameRendered)
    // when video resolution will not change with this subMode switch.
    void NotifySubModeChanged(const std::string& transport_bus_id,
        ExtendedSubMode sub_mode,
        bool force);
    // Must run on operation_thread_. Sends DISPLAY_RESOLUTION if still pending
    // after SwitchExtendedSubMode (skipped when SetExtendedDisplayResolution runs
    // first in the queued batch).
    void FlushPendingDisplayResolutionNotify(int client_id);
    // Must run on operation_thread_.
    void StopClientOnOperationThread(int client_id);
    void StopAllClientsOnOperationThread();
    void DestroyEngineOnOperationThread();

    // for debug
    struct FrameRateStats {
        int64_t frame_count = 0;
        int64_t last_stats_time_ms = 0;
        int64_t last_frame_time_ms = 0;
        double current_fps = 0.0;
        double min_fps = 999.0;
        double max_fps = 0.0;
        int64_t total_interval_ms = 0;
        int interval_count = 0;
    };
    void UpdateAndLogFrameRate(FrameRateStats& stats,
        const std::string& source_name,
        int expected_fps = 0);

    SinkClientListener* sink_client_listener_;
    std::mutex listener_mutex_;
    std::shared_ptr<OdmfListener> odmf_listener_;
    OdmfEngine* odmf_engine_;
    std::unique_ptr<webrtc::Thread> operation_thread_;
    std::unique_ptr<RemoteControlExtendedModeAdapter> remote_control_adapter_;
    std::map<int, SinkClientInfo> client_map_;
    mutable std::mutex client_map_mutex_;  // for PushVideoFrame  client_map_
    int push_video_width_ = 0;
    int push_video_height_ = 0;
    int client_id_seed_;
    bool need_start_server_;
    bool has_created_audio_bus_;
    bool has_connected_audio_bus_;
    std::string auth_info_;
    SinkBigDataInfo big_data_info_;
    SinkCpuAndMemoryInfo cpu_and_mem_info_;
    bool support_h265_hardware_encoder_;
    bool support_h265_hardware_decoder_;
    int audio_client_id_;
    FrameRateStats push_video_frame_stats_;
    bool single_audio_;
    CastMode cast_mode_;
    int port_;
#if defined(OPLUS_ENABLE_H265) && defined(WEBRTC_WIN)
    std::map<int, std::shared_ptr<webrtc::H265DecoderListener>>
        h265_listener_map_;
#endif  // OPLUS_ENABLE_H265 && WEBRTC_WIN

    // Max wait for OdmfEngine::Destroy completion before abandon (see Destroy()).
    // Must cover per-bus Destroy waits inside OdmfEngine (see kDestroyBusWaitMs).
    static constexpr int kDestroyEngineWaitMs = 60000;
    // Max wait for the full Destroy() teardown task on operation_thread_.
    static constexpr int kDestroyOperationWaitMs = kDestroyEngineWaitMs + 5000;
};

#endif  // OPLUS_ODMF_SINK_MANAGER_H_
