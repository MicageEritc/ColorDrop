/******************************************************************************
 ** Copyright 2025-2025 OPLUS Mobile Comm Corp., Ltd.
 ** All rights reserved.
 **
 ** File: sink_client_listener.h
 ** Description: SinkClientListener
 ** Version: 1.0
 ** Date : 2025-03-29
 ** Author: Yongzheng.an
 ** -----------------------------Revision History: ----------------------------
 ** <author>                    <date>     <version > <desc>
 ********************************************************************************/
#ifndef OPLUS_ODMF_SINK_CLIENT_LISTENER_H_
#define OPLUS_ODMF_SINK_CLIENT_LISTENER_H_

class SinkClientListener {
   public:
    virtual ~SinkClientListener() { }

    // Trigger when internal state changes.
    virtual void OnStateChanged(int id, int state) = 0;
    // Trigger when video resolution changes, this info is from decoder.
    virtual void OnVideoResolutionChanged(
        int id, int width, int height, int rotation) = 0;
    // Trigger when video frames are ready to render.
    virtual void OnFirstFramePrepared(int id) = 0;
    // Trigger when record file is empty
    virtual void OnRecordFileEmpty(int id) = 0;
    // Trigger when error happens.
    virtual void OnErrorNotify(int id, int code, const char* reason) = 0;
    // Trigger when first key frame ARGB.
    virtual void OnFirstKeyFrameReceived(
        int id, const uint8_t* data, int width, int height) = 0;
    // Trigger when last key frame ARGB.
    virtual void OnLastKeyFrameReceived(
        int id, const uint8_t* data, int width, int height) = 0;
    // Trigger when return the SetParameters execution result.
    virtual void OnSetParamsResult(int id, bool result) = 0;
    // Trigger when phone fold status changed.
    virtual void OnPhoneFoldStatusChanged(int id, int fold) = 0;
    // Trigger when first video frame sent successfully.
    virtual void OnFirstVideoFrameSent(int id) = 0;
};

#endif  // OPLUS_ODMF_SINK_CLIENT_LISTENER_H_
